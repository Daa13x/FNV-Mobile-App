"""Read-only LAN Pip-Boy bridge. Python 3.10+, standard library only.
Mock snapshots ONLY; no Fallout memory access is implemented.
"""
import argparse
import hashlib
import hmac
import json
import os
import secrets
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MAX_BYTES = 16_384

class State:
    def __init__(self, snapshot, host):
        self.snapshot = snapshot
        self.host = host
        self.code = f'{secrets.randbelow(1_000_000):06d}'
        self.tokens = set()
        self.lock = threading.Lock()
        self.started = time.monotonic()

    def pair(self, code):
        if time.monotonic() - self.started > 600:
            return None
        if not isinstance(code, str) or not hmac.compare_digest(code, self.code):
            return None
        with self.lock:
            token = secrets.token_urlsafe(32)
            self.tokens.add(hashlib.sha256(token.encode()).digest())
            self.code = f'{secrets.randbelow(1_000_000):06d}'
            self.started = time.monotonic()
            return token

    def authorized(self, header):
        if not header.startswith('Bearer '):
            return False
        digest = hashlib.sha256(header[7:].encode()).digest()
        with self.lock:
            return any(hmac.compare_digest(digest, t) for t in self.tokens)


def make_handler(state):
    class Handler(BaseHTTPRequestHandler):
        def respond(self, status, payload):
            body = json.dumps(payload, separators=(',', ':')).encode()
            self.send_response(status)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            if self.path == '/health':
                return self.respond(200, {'status':'ok','mode':'mock','protocol':1})
            if not state.authorized(self.headers.get('Authorization', '')):
                return self.respond(401, {'error':'unauthorized'})
            if self.path == '/v1/snapshot':
                return self.respond(200, state.snapshot)
            return self.respond(404, {'error':'not_found'})

        def do_POST(self):
            if self.path != '/v1/pair':
                return self.respond(404, {'error':'not_found'})
            try:
                size = int(self.headers.get('Content-Length', '0'))
                if size <= 0 or size > MAX_BYTES:
                    return self.respond(413, {'error':'invalid_size'})
                data = json.loads(self.rfile.read(size))
                token = state.pair(data.get('code'))
            except (ValueError, TypeError, json.JSONDecodeError, AttributeError):
                return self.respond(400, {'error':'invalid_json'})
            if not token:
                return self.respond(403, {'error':'invalid_or_expired_code'})
            return self.respond(200, {'token':token,'protocol':1})

        def log_message(self, fmt, *args):
            pass  # Never log pairing codes or bearer tokens.
    return Handler


def run(host='127.0.0.1', port=8765):
    snapshot = json.loads((ROOT/'samples'/'mock_snapshot.json').read_text(encoding='utf-8'))
    state = State(snapshot, host)
    httpd = ThreadingHTTPServer((host, port), make_handler(state))
    print(f'PipBoyRemote MOCK server: http://{host}:{httpd.server_port}', flush=True)
    print('Pairing code (expires in 10 minutes):', state.code, flush=True)
    if host not in ('127.0.0.1', 'localhost', '::1'):
        print('WARNING: HTTP pairing/token traffic is unencrypted on LAN. Use trusted isolated Wi-Fi only.', flush=True)
    httpd.serve_forever()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=8765)
    args = parser.parse_args()
    run(args.host, args.port)
