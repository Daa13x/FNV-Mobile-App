# Prototype protocol v1
GET /health -> {status,mode,protocol} (public)
POST /v1/pair {"code":"123456"} -> {"token":"...","protocol":1} (10 minute expiry; code rotates on success)
GET /v1/snapshot with Authorization: Bearer TOKEN -> sample snapshot

No mutation endpoints. No live game session. HTTP-only demonstration transport; do not use beyond trusted test LAN.

Planned production protocol: authenticated TLS or securely paired encrypted channel, revocation, rate limiting, rotating credentials, capability negotiation, game-session IDs, immutable snapshots and deltas, verified game-thread command dispatch.
