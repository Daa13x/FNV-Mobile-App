# Pass 2: real game integration and security
1. Inspect the user's actual VLK-TTW/xNVSE versions and existing mod setup. Back up saves/profile and measure baseline.
2. Review license/API/build compatibility of AidansLab/PipBoy3000Companion and xNVSE; do not copy upstream code without verification.
3. Implement a read-only Fallout adapter in an isolated mod-manager profile, emitting verified snapshots from the real game. Handle FormID identity, stacked items and load transitions.
4. Replace mock-only bridge with a validated game adapter and clear source status (mock/live/disconnected). Never claim mock data is live.
5. Replace HTTP LAN transport with authenticated encryption and pairing rate limits, device revocation and secure Android token storage.
6. Add snapshot polling or bounded streaming, reconnect/backoff, background lifecycle, error UI, and Android tests.
7. Compile Android APK and verify on physical phone, then test against running VLK-TTW. Save mutation actions for a later pass after read-only proof.

Acceptance: physical phone displays an item picked up in the live game and accurately shows its removal; no active saves altered.
