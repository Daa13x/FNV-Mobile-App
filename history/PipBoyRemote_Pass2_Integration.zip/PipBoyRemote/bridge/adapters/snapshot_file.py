"""Read-only external snapshot adapter. No game integration implied."""
import json
from pathlib import Path

def load_snapshot(path):
    p = Path(path)
    if not p.is_file() or p.is_symlink() or p.stat().st_size > 2_000_000:
        raise ValueError('missing or oversized snapshot')
    data = json.loads(p.read_text(encoding='utf-8'))
    if not isinstance(data, dict) or not isinstance(data.get('inventory'), list):
        raise ValueError('invalid inventory schema')
    return data
