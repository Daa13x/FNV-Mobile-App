# Pip-Boy Remote — Pass 1 prototype

**Status: source-only prototype. No game integration. No APK has been built.**

## What is implemented
- Python standard-library HTTP bridge serving an explicitly MOCK snapshot.
- Six-digit, 10-minute pairing code; token-protected read-only snapshot endpoint.
- Android Kotlin/Jetpack Compose source: pairing, manual refresh, STAT/ITEMS/DATA/RADIO views.
- JSON example covering inventory, character, SPECIAL, quests, map, radio, companions, survival.
- Unit/integration tests for the mock bridge.

## What is NOT implemented
- xNVSE integration, actual VLK-TTW reads, any game writes, live push/WebSocket, APK build, secure LAN transport, persistence, discovery, complete UI.
- Pairing is **HTTP cleartext** on the LAN, and pairing has no rate limiting. **Use only on a trusted isolated local network for testing.** Never expose port 8765 to the internet. No secrets should be used in this prototype.
- The Android app stores the token in memory only and loses it on restart. Manual refresh only.

## Run bridge
From the repository root:
```
python -m unittest discover -s tests -v
python bridge/server.py
```
For physical Android testing on a trusted Wi-Fi, run:
```
python bridge/server.py --host 0.0.0.0
```
Allow TCP 8765 only on the Windows **Private** firewall profile, and block public network access. Use your PC's actual LAN IP in the app. Pair with the code shown in the terminal. **Never forward the port.**

## Android build
Open `android/` in Android Studio with Android SDK 35 and JDK 17; allow Gradle to resolve dependencies, then build/install the app. No Gradle wrapper is included. The source has not been compiled in this environment.

## Roadmap
See `docs/NEXT_PASS.md` and `docs/PROTOCOL.md`.

## Pass 3: external snapshot bridge correction
The bridge now supports `python bridge/server.py --snapshot-file path/to/snapshot.json` and
`python -m bridge.server --snapshot-file path/to/snapshot.json` from the repository root.
It reads the file for each authorized snapshot request and returns HTTP 503 when absent or invalid.
This is **not** a game exporter. Do not label externally supplied snapshots as verified live game state.
Do not expose the development HTTP server to public networks.

### LPS integration boundary
LPS may launch or supervise the bridge in the future, but this package has no LPS connector.
Do not share game data or remote commands with cloud agents by default.
