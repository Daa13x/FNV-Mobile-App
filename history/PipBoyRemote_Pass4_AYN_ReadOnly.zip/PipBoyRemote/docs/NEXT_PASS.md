# Pass 5 — physical game and phone acceptance (not performed)

**Current baseline:** Pass 4 bridge interoperates with a synthetic instance of AYN Dual Screen's documented `/state` endpoint. Python tests and ZIP verification are local only.

## Acceptance sequence (stop on mismatch)

1. On the actual Windows PC, inspect the current VLK-TTW Vortex/mod-manager profile, load order, xNVSE plugins, saves and backup state. Preserve existing profiles and saves; create a disposable test profile.
2. Verify the official AYN Dual Screen plugin's licensed distribution and configure the isolated install. Keep upstream `AllowLanAccess=0` and action permissions off initially; set its `AccessToken` if supported.
3. Launch via VLK-TTW's existing xNVSE-compatible entrypoint. Confirm the xNVSE log and AYN log report successful plugin loading. A DLL present on disk is not runtime proof.
4. On the PC only, inspect `http://127.0.0.1:27303/state` with upstream authentication. Confirm `ready:true`, `game:FalloutNV`, and a progressing `tick`; do not copy any real save/player information to public bug reports.
5. Start `python -m bridge.server --ayn-port 27303`. Pair with a synthetic/local HTTP client. Confirm `/v1/snapshot` inventory IDs/counts agree with the game. Refuse mock fallback. Simulate upstream absence and prove HTTP 503.
6. Create a genuine Android Gradle wrapper/build environment, compile an APK and install on a test phone. Validate LAN pairing, manual refresh and layout on portrait orientation.
7. Pick up and drop a cheap test item in-game and confirm the same item count and ID changes on the phone. Validate at least one TTW Capital Wasteland location and one Mojave location without changing saves.
8. Harden transport: TLS or another secure tunnel, token persistence/revocation UI, session generation, stale feed warnings, bounded update polling. Retest all legacy scenarios.
9. Only after live read-only proof, consider independently approved equipment/aid actions; command acknowledged != verified in-game effect. Do not enable mutations as part of a read-only milestone.
10. If desired, start a separate LPS integration task with current canonical onboarding, sync policy and a distinct Fallout connection identity. Do not inject game data into LPS personal sync automatically.

## Do not claim yet

- AYN compatibility with current **VLK-TTW** specifically.
- An installed or functioning Android APK.
- Save safety across hours of gameplay.
- Secure production LAN pairing.
- Runtime functionality of radio control, map drawing, or inventory mutations.
