# Pip-Boy Remote — Pass 4: Read-only AYN adapter

**Status:** Prototype source, not an installed mod or verified APK. The AYN adapter is tested against a synthetic HTTP server, **not a running VLK-TTW session**. The Android app has not been compiled here.

## What changed from Pass 3

- Added a *read-only* adapter that fetches `/state` from an **independently installed** AYN Dual Screen xNVSE mod on `127.0.0.1` (default port **27303**).
- Projects the documented AYN player, SPECIAL, inventory, quest, map, radio and survival fields to our original Android snapshot schema.
- Explicitly disables all remote gameplay commands through this bridge, even if the upstream mod has command permissions.
- Rejects upstream `ready:false`, invalid schemas, failed connections and oversize replies with HTTP 503; never silently falls back to mock data.
- Existing mock mode and snapshot-file mode remain available. File input is labelled `external-file-unverified`.
- Pairing codes are one-use, paired sessions can be revoked, and five failed pairing attempts per IP per minute cause HTTP 429.
- Seventeen Python tests pass (see `docs/VERIFICATION.md`).

## Install prerequisites and isolation

1. Install Python 3.10+ on the Windows PC. Nothing in this ZIP is a compiled APK or NVSE DLL.
2. **Independently** obtain AYN Dual Screen from its official upstream repository: https://github.com/Abacus1829/ayn-dual-screen . We do **not** ship its code, assets or binaries. Follow the upstream installation instructions in an *isolated VLK-TTW mod-manager profile*; back up saves and record the original plugin list first.
3. Read the upstream restrictions in `LICENSE.txt` and its `falloutnv/README.md`. Its source-available licence does not permit redistribution of modified builds/source except specified exceptions. Our original adapter calls a documented HTTP endpoint; it includes no upstream source code.
4. Check the plugin's own INI (`Data\\NVSE\\Plugins\\AynDualScreen.ini` in the installed mod view). For read-only evaluation, set `AllowLanAccess=0`, and disable game-control permissions such as `AllowEquip`, `AllowUse`, `AllowDrop`, `AllowFastTravel`, `AllowRadio` and `AllowSetQuest`. Defaults in the upstream project may be permissive. Set `AccessToken` if supported and provide the same token via `PIPBOY_AYN_TOKEN` environment variable. Do **not** make its HTTP port internet-accessible.
5. Launch the game, load a save, and confirm the plugin reports an active localhost listener. This is **not** yet verified on your PC.

## Start the bridge

From this project root:

```powershell
python -m unittest discover -s tests -v
# Windows PowerShell, optional if the upstream AccessToken is set:
$env:PIPBOY_AYN_TOKEN = 'your-upstream-access-token'
python -m bridge.server --ayn-port 27303
```

By default the bridge binds only to `127.0.0.1:8765`, preventing your phone from reaching it. First verify loopback operation on the PC. To test the **existing Android source** on a physical phone over trusted Wi-Fi, explicitly use:

```powershell
python -m bridge.server --ayn-port 27303 --host 0.0.0.0
```

Only allow TCP 8765 on the Windows **Private** firewall profile, and remove that rule after testing. Do not forward or expose either port publicly. The phone pairs with the code printed in the bridge console, then fetches `/v1/snapshot`. The phone must use the PC's LAN IP, not `localhost`.

**Security limitation:** Our pairing/token traffic is still unencrypted HTTP. An attacker with access to the network path can observe the token. Use this prototype only on a trusted isolated LAN; never reuse important credentials as pairing codes. A TLS-secured transport and hardened device identity are not implemented.

### Other modes

```powershell
python -m bridge.server                           # explicit MOCK data
python -m bridge.server --snapshot-file C:\\path\\state.json  # external file, provenance unknown
```

Mutations through our bridge are intentionally unsupported. `/v1/unpair` lets a client revoke its own current bearer token; the Android UI does not yet expose that control.

## Limitations

- **Not verified against your VLK-TTW modpack, save, load order or game runtime.** Upstream's own TTW support claim is not our acceptance evidence.
- AYN upstream supplies a `tick` count. Our bridge reflects it but does not presently detect a stalled game feed; `bridgeReadAtUnixMs` is bridge retrieval time, *not* a game-update timestamp.
- Android remains manual-refresh, not streaming/push. No Android Studio/Gradle APK build performed here.
- This package provides no native xNVSE plugin, game assets, write commands, or LPS repository modifications.
- Android still needs real-device UX testing. Upstream map marker fields are passed as read-only data but the current Android UI does not render a visual map.

See `docs/VERIFICATION.md`, `docs/UPSTREAM_REVIEW.md` and `docs/LPS_BOUNDARY.md` for detailed receipts and the next pass.
