package com.pipboyremote

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val phosphor = Color(0xFF73FF8A)
private val bg = Color(0xFF07130A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PipBoyScreen() }
    }
}

private fun request(url: String, token: String? = null, code: String? = null): JSONObject {
    val connection = URL(url).openConnection() as HttpURLConnection
    connection.connectTimeout = 4000
    connection.readTimeout = 4000
    try {
        if (token != null) connection.setRequestProperty("Authorization", "Bearer $token")
        if (code != null) {
            connection.requestMethod = "POST"
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json")
            connection.outputStream.use { it.write(JSONObject().put("code", code).toString().toByteArray()) }
        }
        val status = connection.responseCode
        if (status !in 200..299) throw IllegalStateException("HTTP $status")
        return JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
    } finally { connection.disconnect() }
}

@Composable
fun PipBoyScreen() {
    var host by remember { mutableStateOf("192.168.1.10") }
    var code by remember { mutableStateOf("") }
    var token by remember { mutableStateOf("") }
    var snapshot by remember { mutableStateOf<JSONObject?>(null) }
    var error by remember { mutableStateOf("Not connected — read-only bridge") }
    var tab by remember { mutableStateOf("ITEMS") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val tabs = listOf("STAT", "ITEMS", "DATA", "RADIO")
    MaterialTheme(colorScheme = darkColorScheme(primary = phosphor, background = bg, surface = bg, onSurface = phosphor, onBackground = phosphor)) {
        Column(Modifier.fillMaxSize().background(bg).padding(16.dp)) {
            Text("PIP-BOY REMOTE", style = MaterialTheme.typography.headlineMedium, color = phosphor)
            Text("PROTOTYPE • READ ONLY • ${snapshot?.optString("source") ?: "OFFLINE"}", color = phosphor)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(host, { host = it }, label = { Text("PC LAN IP") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(code, { code = it }, label = { Text("Pairing code") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = !busy, onClick = {
                    busy = true
                    scope.launch {
                        try {
                            val response = withContext(Dispatchers.IO) { request("http://$host:8765/v1/pair", code = code) }
                            token = response.getString("token")
                            error = "Paired; tap Refresh"
                        } catch (e: Exception) { error = "Pair failed: ${e.message}" }
                        finally { busy = false }
                    }
                }) { Text("PAIR") }
                Button(enabled = !busy && token.isNotEmpty(), onClick = {
                    busy = true
                    scope.launch {
                        try {
                            snapshot = withContext(Dispatchers.IO) { request("http://$host:8765/v1/snapshot", token) }
                            error = "Snapshot received (manual refresh)"
                        } catch (e: Exception) { error = "Refresh failed: ${e.message}" }
                        finally { busy = false }
                    }
                }) { Text("REFRESH") }
            }
            Text(error, color = phosphor)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                tabs.forEach { name -> TextButton(onClick = { tab = name }) { Text(name, color = if (tab == name) Color.White else phosphor) } }
            }
            val s = snapshot
            if (s == null) {
                Text("Pair to the bridge, then refresh. The data source will be shown above.")
            } else {
                when (tab) {
                    "STAT" -> {
                        val ch = s.optJSONObject("character")
                        Text("${ch?.optString("name") ?: "Unknown"}  LEVEL ${ch?.optInt("level") ?: 0}")
                        Text("HP ${ch?.optInt("hp") ?: 0}/${ch?.optInt("maxHp") ?: 0}  AP ${ch?.optInt("ap") ?: 0}/${ch?.optInt("maxAp") ?: 0}")
                        Text("CAPS ${if (ch?.has("caps") == true) ch.optInt("caps").toString() else "Unknown"}  LOCATION ${ch?.optString("location") ?: "?"}")
                        val special = s.optJSONObject("special")
                        special?.keys()?.forEach { key -> Text("${key.uppercase()}: ${special.optInt(key)}") }
                    }
                    "ITEMS" -> {
                        val arr = s.optJSONArray("inventory")
                        val rows = (0 until (arr?.length() ?: 0)).mapNotNull { arr?.optJSONObject(it) }
                        LazyColumn(modifier = Modifier.weight(1f)) { items(rows) { item ->
                            Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                                Text("${item.optString("name")}  ×${item.optInt("count")}")
                                Text("${item.optString("category")} ${if (item.optBoolean("equipped")) "• EQUIPPED" else ""}")
                                HorizontalDivider(color = phosphor.copy(alpha = 0.25f))
                            }
                        } }
                    }
                    "DATA" -> {
                        Text("WORLD: ${s.optJSONObject("map")?.optString("world") ?: "Unknown"}")
                        val quests = s.optJSONArray("quests")
                        for (i in 0 until (quests?.length() ?: 0)) Text("QUEST: ${quests?.optJSONObject(i)?.optString("title")}")
                    }
                    "RADIO" -> Text("Station: ${s.optJSONObject("radio")?.optString("station") ?: "None"} (read-only)")
                }
            }
        }
    }
}
